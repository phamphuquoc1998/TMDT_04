﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TMDT.Models
{
    public class Price
    {
        public int ID { get; set; }
        public int price { get; set; }
    }
}